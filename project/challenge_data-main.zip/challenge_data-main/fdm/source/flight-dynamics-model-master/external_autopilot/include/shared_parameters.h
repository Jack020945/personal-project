c   This is the include "header" for common parameters used by the shared types
c   It is intended to be similar to a .h file.
c   Joel Allardyce 13 July 2022    Southwest Research Institute
c
c   7/13/22 Initial coding
c

      integer(C_INT) :: maxparts
      parameter (maxparts = 50)