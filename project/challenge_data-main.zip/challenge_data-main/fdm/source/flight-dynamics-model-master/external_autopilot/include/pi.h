
        real(C_DOUBLE) pi, halfpi, twopi, rad_to_deg, deg_to_rad

        parameter (pi = 3.1415 92653 58979 32384 62643)
        parameter (halfpi = pi/2.d0, twopi=2.d0*pi)
        parameter (rad_to_deg = 180.d0/pi, deg_to_rad = pi/180.d0)

